create
    definer = admin@`%` procedure INSERTAR_POLIZA(OUT _id_poliza int, IN _fid_metodo int, IN _fid_vehiculo int,
                                                  IN _fid_cliente int, IN _precio_base decimal(10, 2),
                                                  IN _fecha_vigencia_desde date, IN _fecha_vigencia_fin date)
BEGIN
	SET _id_poliza = @@last_insert_id;
	INSERT INTO poliza(id_poliza,fid_metodo,fid_vehiculo,fid_cliente,precio_base,fecha_vigencia_desde,fecha_vigencia_fin,activo) 
				VALUES(_id_poliza,_fid_metodo,_fid_vehiculo,_fid_cliente,_precio_base,_fecha_vigencia_desde,_fecha_vigencia_fin,1);
END;

