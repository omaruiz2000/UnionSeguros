create
    definer = admin@`%` procedure LISTAR_MARCA_VEHICULO()
BEGIN
	SELECT id_marca_vehiculo, marca FROM marca_vehiculo WHERE activo = 1;
END;

