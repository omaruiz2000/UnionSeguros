create
    definer = admin@`%` procedure ELIMINAR_VEHICULO(IN _id_vehiculo int)
BEGIN
	UPDATE vehiculo SET activo = 0 WHERE id_vehiculo = _id_vehiculo;
END;

