create
    definer = admin@`%` procedure LISTAR_POLIZA()
BEGIN
	SELECT id_poliza,fid_metodo,fid_vehiculo,fid_cliente,precio_base,fecha_vigencia_desde,fecha_vigencia_fin 
    FROM poliza WHERE activo = 1;
END;

