create
    definer = admin@`%` procedure ELIMINAR_POLIZA(IN _id_poliza int)
BEGIN
	UPDATE poliza SET activo = 0 WHERE id_poliza = _id_poliza;
END;

