create
    definer = admin@`%` procedure INSERTAR_BOLETA_DE_VENTA(OUT _id_boleta int, IN _fid_soat int, IN _fecha_emision date,
                                                           IN _monto decimal(10, 2))
BEGIN
	SET _id_boleta = @@last_insert_id;
	INSERT INTO boleta_de_venta(id_boleta,fid_soat,fecha_emision,monto,activo) VALUES(_id_boleta,_fid_soat,_fecha_emision,_monto,1);
END;

