create
    definer = admin@`%` procedure LISTAR_BOLETA_DE_VENTA()
BEGIN
	SELECT id_boleta,fid_soat,fecha_emision,monto FROM boleta_de_venta WHERE activo = 1;
END;

