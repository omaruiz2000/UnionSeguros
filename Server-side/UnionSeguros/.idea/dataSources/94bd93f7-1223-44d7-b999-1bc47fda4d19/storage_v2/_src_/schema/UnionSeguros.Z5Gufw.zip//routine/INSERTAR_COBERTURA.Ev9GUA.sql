create
    definer = admin@`%` procedure INSERTAR_COBERTURA(OUT _id_cobertura int, IN _nombre varchar(100),
                                                     IN _descripcion varchar(100), IN _costo decimal(10, 2))
BEGIN
	SET _id_cobertura = @@last_insert_id;
	INSERT INTO cobertura(id_cobertura,nombre,descripcion,costo,activo) VALUES(_id_cobertura,_nombre,_descripcion,_costo,1);
END;

