create
    definer = admin@`%` procedure MODIFICAR_MARCA_VEHICULO(IN _id_marca_vehiculo int, IN _marca varchar(30))
BEGIN
	UPDATE marca_vehiculo SET marca = _marca
    WHERE id_marca_vehiculo = _id_marca_vehiculo;
END;

