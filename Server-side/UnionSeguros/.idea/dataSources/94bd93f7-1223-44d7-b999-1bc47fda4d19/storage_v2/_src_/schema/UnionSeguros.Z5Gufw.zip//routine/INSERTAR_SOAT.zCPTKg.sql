create
    definer = admin@`%` procedure INSERTAR_SOAT(OUT _id_soat int, IN _fid_plan_soat int, IN _fid_poliza int,
                                                IN fecha_de_emision date, IN monto_prima decimal(10, 2))
BEGIN
	SET _id_soat = @@last_insert_id;
	INSERT INTO soat(id_soat,fid_plan_soat,fid_poliza,fecha_de_emision,monto_prima,activo) 
				VALUES(_id_soat,_fid_plan_soat,_fid_poliza,_fecha_de_emision,_monto_prima,1);
END;

