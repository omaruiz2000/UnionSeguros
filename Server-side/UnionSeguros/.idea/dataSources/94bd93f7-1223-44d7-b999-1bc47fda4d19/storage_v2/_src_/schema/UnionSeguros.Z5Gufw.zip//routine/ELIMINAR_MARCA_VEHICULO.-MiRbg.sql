create
    definer = admin@`%` procedure ELIMINAR_MARCA_VEHICULO(IN _id_marca_vehiculo int)
BEGIN
	UPDATE marca_vehiculo SET activo = 0 WHERE id_marca_vehiculo = _id_marca_vehiculo;
END;

