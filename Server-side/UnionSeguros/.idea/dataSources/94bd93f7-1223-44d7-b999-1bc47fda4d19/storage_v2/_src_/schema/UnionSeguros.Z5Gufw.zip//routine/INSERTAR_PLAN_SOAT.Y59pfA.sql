create
    definer = admin@`%` procedure INSERTAR_PLAN_SOAT(OUT _id_plan_soat int, IN _cobertura decimal(10, 2),
                                                     IN _precio decimal(10, 2))
BEGIN
	SET _id_plan_soat = @@last_insert_id;
	INSERT INTO plan_soat(id_plan_soat,cobertura,precio,activo) VALUES(_id_plan_soat,_cobertura,_precio,1);
END;

