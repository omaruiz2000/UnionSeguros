create
    definer = admin@`%` procedure LISTAR_COBERTURA()
BEGIN
	SELECT id_cobertura,nombre,descripcion,costo FROM cobertura WHERE activo = 1;
END;

