create
    definer = admin@`%` procedure MODIFICAR_VEHICULO(IN _id_vehiculo int, IN _fid_tipo_uso int, IN _fid_modelo int,
                                                     IN _fid_persona int, IN _anho_fabricacion date,
                                                     IN _numero_asientos int, IN _placa varchar(15))
BEGIN
	UPDATE vehiculo SET fid_tipo_uso = _fid_tipo_uso, fid_modelo = _fid_modelo, fid_persona = _fid_persona, 
						anho_fabricacion = _anho_fabricacion, numero_asientos = _numero_asientos, placa = _placa
    WHERE id_vehiculo = _id_vehiculo;
END;

