create
    definer = admin@`%` procedure MODIFICAR_COBERTURA(IN _id_cobertura int, IN _nombre varchar(100),
                                                      IN _descripcion varchar(100), IN _costo decimal(10, 2))
BEGIN
	UPDATE cobertura SET nombre = _nombre, descripcion = _descripcion, costo = _costo
    WHERE id_cobertura = _id_cobertura;
END;

