create
    definer = admin@`%` procedure ELIMINAR_MODELO(IN _id_modelo int)
BEGIN
	UPDATE modelo SET activo = 0 WHERE id_modelo = _id_modelo;
END;

