create
    definer = admin@`%` procedure ELIMINAR_COBERTURA(IN _id_cobertura int)
BEGIN
	UPDATE cobertura SET activo = 0 WHERE id_cobertura = _id_cobertura;
END;

