create
    definer = admin@`%` procedure ELIMINAR_TIPO_VEHICULO(IN _id_tipo_vehiculo int)
BEGIN
	UPDATE tipo_vehiculo SET activo = 0 WHERE id_tipo_vehiculo = _id_tipo_vehiculo;
END;

