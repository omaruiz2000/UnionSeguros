create
    definer = admin@`%` procedure ELIMINAR_SOAT(IN _id_soat int)
BEGIN
	UPDATE soat SET activo = 0 WHERE id_soat = _id_soat;
END;

