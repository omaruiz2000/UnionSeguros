create
    definer = admin@`%` procedure INSERTAR_MARCA_VEHICULO(OUT _id_marca_vehiculo int, IN _marca varchar(30))
BEGIN
	SET _id_marca_vehiculo = @@last_insert_id;
	INSERT INTO marca_vehiculo(id_marca_vehiculo,marca,activo) VALUES(_id_marca_vehiculo,_marca,1);
END;

