create
    definer = admin@`%` procedure INSERTAR_TIPO_VEHICULO(OUT _id_tipo_vehiculo int, IN _nombre_tipo_vehiculo varchar(30))
BEGIN
	SET _id_tipo_vehiculo = @@last_insert_id;
	INSERT INTO tipo_vehiculo(id_tipo_vehiculo,nombre_tipo_vehiculo,activo) VALUES(_id_tipo_vehiculo,_nombre_tipo_vehiculo,1);
END;

