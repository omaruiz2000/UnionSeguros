create
    definer = admin@`%` procedure INSERTAR_TIPO_USO(OUT _id_tipo_uso int, IN _nombre_tipo_uso varchar(30))
BEGIN
	SET _id_tipo_uso = @@last_insert_id;
	INSERT INTO tipo_uso(id_tipo_uso,nombre_tipo_uso,activo) VALUES(_id_tipo_uso,_nombre_tipo_uso,1);
END;

