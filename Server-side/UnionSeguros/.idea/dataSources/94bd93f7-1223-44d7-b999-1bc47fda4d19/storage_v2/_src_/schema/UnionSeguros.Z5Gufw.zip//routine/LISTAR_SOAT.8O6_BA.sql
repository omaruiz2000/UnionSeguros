create
    definer = admin@`%` procedure LISTAR_SOAT()
BEGIN
	SELECT id_soat,fid_plan_soat,fid_poliza,fecha_de_emision,monto_prima FROM soat WHERE activo = 1;
END;

