create
    definer = admin@`%` procedure MODIFICAR_PLAN_SOAT(IN _id_plan_soat int, IN _cobertura decimal(10, 2),
                                                      IN _precio decimal(10, 2))
BEGIN
	UPDATE plan_soat SET cobertura = _cobertura, precio = _precio
    WHERE id_plan_soat = _id_plan_soat;
END;

